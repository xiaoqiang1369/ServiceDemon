package com.example.leon.myapplication

/**
 *   description:
 *   created by crx on 2018/12/13 15:37
 */

const val MSG_SAY_HELLO = 1