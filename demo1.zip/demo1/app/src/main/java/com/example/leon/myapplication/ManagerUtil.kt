package com.example.leon.myapplication

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import android.util.Log

import android.content.Context.BIND_AUTO_CREATE
import com.example.leon.myapplication.services.MyService

/**
 * Description：记得填写
 * Created by leon on 2018/12/6.
 */
class ManagerUtil {

    lateinit var service: MyService

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {

            val myBinder = binder as MyService.LocalBinder
            service = myBinder.service

            Log.i("Kathy", "onServiceConnected")
        }

        override fun onServiceDisconnected(name: ComponentName) {
            Log.i("Kathy", "onServiceDisconnected")
        }
    }


    fun bindService(context: Context) {
        context.bindService(Intent(context, MyService::class.java), conn, BIND_AUTO_CREATE)
    }

    fun unBindService(context: Context) {
        context.unbindService(conn)
    }


}
