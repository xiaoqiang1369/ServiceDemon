package com.example.leon.myapplication

import android.os.Bundle
import android.support.v7.app.AppCompatActivity

class Main3Activity : AppCompatActivity() {

    private var managerUtil = ManagerUtil()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        managerUtil.bindService(this)
    }


    override fun onDestroy() {
        super.onDestroy()

        managerUtil.unBindService(this)
    }
}
