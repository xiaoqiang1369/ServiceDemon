package com.example.leon.myapplication

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.support.v7.app.AppCompatActivity
import android.util.Log
import com.example.leon.myapplication.services.MyService

class Main2Activity : AppCompatActivity() {

    private lateinit var service: MyService

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {

            service = (binder as MyService.LocalBinder).service

            Log.e("Main2Activity", "onServiceConnected")
        }

        override fun onServiceDisconnected(name: ComponentName) {

            Log.e("Main2Activity", "onServiceDisconnected")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        bindService(Intent(this, MyService::class.java), conn, Context.BIND_AUTO_CREATE)
    }


    override fun onDestroy() {
        super.onDestroy()

        unbindService(conn)
    }
}
